/****************************************************************************
** Meta object code from reading C++ file 'mainwindow.h'
**
** Created by: The Qt Meta Object Compiler version 68 (Qt 6.3.0)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include <memory>
#include "../../colors/mainwindow.h"
#include <QtGui/qtextcursor.h>
#include <QScreen>
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'mainwindow.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 68
#error "This file was generated using the moc from 6.3.0. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
struct qt_meta_stringdata_Widget_t {
    const uint offsetsAndSize[46];
    char stringdata0[211];
};
#define QT_MOC_LITERAL(ofs, len) \
    uint(offsetof(qt_meta_stringdata_Widget_t, stringdata0) + ofs), len 
static const qt_meta_stringdata_Widget_t qt_meta_stringdata_Widget = {
    {
QT_MOC_LITERAL(0, 6), // "Widget"
QT_MOC_LITERAL(7, 7), // "setInfo"
QT_MOC_LITERAL(15, 0), // ""
QT_MOC_LITERAL(16, 4), // "newR"
QT_MOC_LITERAL(21, 4), // "newG"
QT_MOC_LITERAL(26, 4), // "newB"
QT_MOC_LITERAL(31, 9), // "newSlider"
QT_MOC_LITERAL(41, 10), // "identFirst"
QT_MOC_LITERAL(52, 11), // "identSecond"
QT_MOC_LITERAL(64, 10), // "identThird"
QT_MOC_LITERAL(75, 9), // "newLFirst"
QT_MOC_LITERAL(85, 10), // "newLSecond"
QT_MOC_LITERAL(96, 9), // "newLThird"
QT_MOC_LITERAL(106, 10), // "newLFourth"
QT_MOC_LITERAL(117, 9), // "newCFirst"
QT_MOC_LITERAL(127, 10), // "newCSecond"
QT_MOC_LITERAL(138, 9), // "newCThird"
QT_MOC_LITERAL(148, 10), // "newCFourth"
QT_MOC_LITERAL(159, 9), // "newRFirst"
QT_MOC_LITERAL(169, 10), // "newRSecond"
QT_MOC_LITERAL(180, 9), // "newRThird"
QT_MOC_LITERAL(190, 10), // "newRFourth"
QT_MOC_LITERAL(201, 9) // "onPallete"

    },
    "Widget\0setInfo\0\0newR\0newG\0newB\0newSlider\0"
    "identFirst\0identSecond\0identThird\0"
    "newLFirst\0newLSecond\0newLThird\0"
    "newLFourth\0newCFirst\0newCSecond\0"
    "newCThird\0newCFourth\0newRFirst\0"
    "newRSecond\0newRThird\0newRFourth\0"
    "onPallete"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_Widget[] = {

 // content:
      10,       // revision
       0,       // classname
       0,    0, // classinfo
      21,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: name, argc, parameters, tag, flags, initial metatype offsets
       1,    0,  140,    2, 0x0a,    1 /* Public */,
       3,    0,  141,    2, 0x0a,    2 /* Public */,
       4,    0,  142,    2, 0x0a,    3 /* Public */,
       5,    0,  143,    2, 0x0a,    4 /* Public */,
       6,    0,  144,    2, 0x0a,    5 /* Public */,
       7,    1,  145,    2, 0x0a,    6 /* Public */,
       8,    1,  148,    2, 0x0a,    8 /* Public */,
       9,    1,  151,    2, 0x0a,   10 /* Public */,
      10,    0,  154,    2, 0x0a,   12 /* Public */,
      11,    0,  155,    2, 0x0a,   13 /* Public */,
      12,    0,  156,    2, 0x0a,   14 /* Public */,
      13,    0,  157,    2, 0x0a,   15 /* Public */,
      14,    0,  158,    2, 0x0a,   16 /* Public */,
      15,    0,  159,    2, 0x0a,   17 /* Public */,
      16,    0,  160,    2, 0x0a,   18 /* Public */,
      17,    0,  161,    2, 0x0a,   19 /* Public */,
      18,    0,  162,    2, 0x0a,   20 /* Public */,
      19,    0,  163,    2, 0x0a,   21 /* Public */,
      20,    0,  164,    2, 0x0a,   22 /* Public */,
      21,    0,  165,    2, 0x0a,   23 /* Public */,
      22,    0,  166,    2, 0x0a,   24 /* Public */,

 // slots: parameters
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::QString,    2,
    QMetaType::Void, QMetaType::QString,    2,
    QMetaType::Void, QMetaType::QString,    2,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,

       0        // eod
};

void Widget::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        auto *_t = static_cast<Widget *>(_o);
        (void)_t;
        switch (_id) {
        case 0: _t->setInfo(); break;
        case 1: _t->newR(); break;
        case 2: _t->newG(); break;
        case 3: _t->newB(); break;
        case 4: _t->newSlider(); break;
        case 5: _t->identFirst((*reinterpret_cast< std::add_pointer_t<QString>>(_a[1]))); break;
        case 6: _t->identSecond((*reinterpret_cast< std::add_pointer_t<QString>>(_a[1]))); break;
        case 7: _t->identThird((*reinterpret_cast< std::add_pointer_t<QString>>(_a[1]))); break;
        case 8: _t->newLFirst(); break;
        case 9: _t->newLSecond(); break;
        case 10: _t->newLThird(); break;
        case 11: _t->newLFourth(); break;
        case 12: _t->newCFirst(); break;
        case 13: _t->newCSecond(); break;
        case 14: _t->newCThird(); break;
        case 15: _t->newCFourth(); break;
        case 16: _t->newRFirst(); break;
        case 17: _t->newRSecond(); break;
        case 18: _t->newRThird(); break;
        case 19: _t->newRFourth(); break;
        case 20: _t->onPallete(); break;
        default: ;
        }
    }
}

const QMetaObject Widget::staticMetaObject = { {
    QMetaObject::SuperData::link<QWidget::staticMetaObject>(),
    qt_meta_stringdata_Widget.offsetsAndSize,
    qt_meta_data_Widget,
    qt_static_metacall,
    nullptr,
qt_incomplete_metaTypeArray<qt_meta_stringdata_Widget_t
, QtPrivate::TypeAndForceComplete<Widget, std::true_type>
, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<QString, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<QString, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<QString, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>


>,
    nullptr
} };


const QMetaObject *Widget::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *Widget::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_Widget.stringdata0))
        return static_cast<void*>(this);
    return QWidget::qt_metacast(_clname);
}

int Widget::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QWidget::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 21)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 21;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 21)
            *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType();
        _id -= 21;
    }
    return _id;
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
